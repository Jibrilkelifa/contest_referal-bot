from decouple import config, Csv

BOT_TOKEN = config('BOT_TOKEN')
BOT_OWNER = config('BOT_OWNER')
CHANNEL_GROUP_CHAT_ID = config('CHANNEL_GROUP_CHAT_ID')
DATETIME_FORMAT = config('DATETIME_FORMAT')
TIMIZONE = config('TIMIZONE')