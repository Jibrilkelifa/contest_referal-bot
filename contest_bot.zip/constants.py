NOT_STARTED_YET = 'Not Started Yet'
STARTED = 'Started'
FINISHED = 'Finished'